//Malak Moustafa 20237015
//Jumanah Muhammad 20237003
#include "Passenger.h"
#include <iostream>

int Passenger::totalpassengers = 0;
void Passenger::DisplayPassengerDetails() const
{
    cout << "Passenger details: " << endl;
    cout << "Name: " << name << endl;
    cout << "ID: " << ID << endl;
}

void Passenger::DisplayTotalPassengers()
{
    cout << "Total passengers: " << totalpassengers;
}
istream &operator>>(istream &is, Passenger &passenger) // return passenger details
{
    cout << "Enter passenger name: " << endl;
    is >> passenger.name;
    cout << "Enter passenger ID: " << endl;
    is >> passenger.ID;
    return is;
}

