//Malak Moustafa 20237015
//Jumanah Muhammad 20237003
#include "Flight.h"
#include <cstring>

ostream &operator<<(ostream &os, const Flight &flight) // Displaying flight details using operator <<
{
    flight.DisplayFlightDetails();
    return os;
}
// a private function member to resize the passengers' array
void Flight::ResizePassengersArray()
{
    int new_capacity = seating_capacity + 6; // assuming that we have 6 seats per row
    Passenger *new_passengers = new Passenger[new_capacity];
    for (int i = 0; i < passengers_count; i++)
    {
        new_passengers[i] = passengers[i];
    }
    delete[] passengers; // deallocate the old array
    passengers = new_passengers;
    seating_capacity = new_capacity;
}

void Flight::InitialSeatingPlan()
{
    int rows = seating_capacity / 6;
    seating_plan = new char *[rows]; // creating a 2D array using pointer to a pointer
    for (int i = 0; i < rows; i++)
    {
        seating_plan[i] = new char[6];
    }
    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < 6; ++j)
        {
            seating_plan[i][j] = '0';
        }
    } // creating a 6-sized array in each row and initializing each one with zeros (using nested loops)
}

bool Flight::search_passenger(const string name)
{
    for (int i = 0; i < passengers_count; i++)
    {
        if (passengers[i].getName() == name)
        {
            return true;
        }
    }
    return false;
} // to search if a passenger is present or not

bool Flight::search_seat(int seat_num) const
{
    int row = (seat_num - 1) / 6;
    int seat = (seat_num - 1) % 6;
    if (seat >= 6 || row < 0 || seat < 0)
    {
        return false;
    }

    return (seating_plan[row][seat] == 'X') ? true : false;
} // search for the seat number using its array indicies

void Flight::DisplayFlightDetails() const
{
    cout << "Flight Number: " << flight_num << endl;
    cout << "Destination: " << destination << endl;
    cout << "Departure Time: " << departure_time << " " << time_zone << endl;
    cout << "Seating Capacity: " << seating_capacity - 6 << endl;
    cout << "Seating plan: \n";
    for (int i = 0; i < seating_capacity / 6; i++)
    {
        for (int j = 0; j < 6; j++)
        {
            cout << seating_plan[i][j] << " ";
        }
        cout << endl;
    }
}

Flight &Flight::operator++() // add a new row if we need to expand the seating capacity
{
    seating_capacity += 6; // new row addition
    int rows = seating_capacity / 6;
    char **new_seatings = new char *[rows];
    for (int i = 0; i < rows; i++)
    {
        new_seatings[i] = new char[6];
    } // create 6 seats for each row

    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < 6; ++j)
        {
            new_seatings[i][j] = '0';
        }
    } // Initialize all elements to 0 using nested loops

    for (int i = 0; i < rows - 1; i++)
    {
        for (int j = 0; j < 6; j++)
        {
            new_seatings[i][j] = seating_plan[i][j];
        }
    } // copies the old seating plan into the new seating plan
    for (int i = 0; i < rows - 1; i++)
    {
        delete[] seating_plan[i];
    } // Deletes old array to free memory
    delete[] seating_plan;
    // fill seating plan with new_seatings
    seating_plan = new_seatings; // seating_plan now points to the new, expanded array they share the same memory address
    return *this;                // to allow possible chaining
}

Flight &Flight::operator+=(const Passenger p)
{
    bool seatAssigned = false; // a flag to track if a seat is assigned
    // Find an empty seat in the seating plan
    for (int i = 0; i < seating_capacity / 6; ++i)
    { // Iterate over rows
        for (int j = 0; j < 6; ++j)
        { // Iterate over seats in the row
            if (seating_plan[i][j] == '0')
            { // If the seat is empty
                // Assign the passenger to this seat
                seating_plan[i][j] = 'X';           // Mark seat as reserved
                passengers[passengers_count++] = p; // Add the passenger to the passengers array
                int seat_num = i * 6 + j + 1;
                cout << "Passenger " << p.getName() << " assigned to seat (" << seat_num << ").\n";
                seatAssigned = true; // Stop searching after assigning a seat
                return *this;        // Return the current object (this) to allow chaining
            }
        }
    }
    if (!seatAssigned)
    {
        cout << "No available seat for passenger " << p.getName() << ".\n";
    }

    return *this;
}
Flight &Flight::operator--(int)
{
    if (passengers_count > 0)
    {
        Passenger last_passenger = passengers[passengers_count - 1]; // the last passenger
        // Find the seat of the last passenger
        int row = passengers_count / 6;
        int seat = passengers_count % 6;
        seating_plan[row][seat] = '0'; // mark the seat as available
        passengers_count--;
        cout << "Passenger " << last_passenger.getName() << " has been removed." << endl;
        cout << "The total of passengers is " << passengers_count << endl;
    }
    else
    {
        cout << "No passengers to remove." << endl;
    }
    return *this;
}
Flight &Flight::operator-=(int num_passengers)
{
    if (num_passengers <= 0)
    {
        cout << "Invalid number of passengers to remove." << endl;
        return *this;
    }
    for (int i = 0; i < num_passengers; ++i)
    {
        if (passengers_count > 0)
        {
            Passenger last_passenger = passengers[passengers_count - 1]; // remove the last passenger
            passengers_count--;                                          // decrement passenger count
            int row = (passengers_count) / 6;
            int seat = (passengers_count) % 6;
            seating_plan[row][seat] = '0';
            cout << "Passenger " << last_passenger.getName() << " has been removed." << endl;
        }
        else
        {
            cout << "No more passengers to remove." << endl;
            break; // If there are no passengers left, stop removing.
        }
    }

    return *this;
}
void Flight::removePassenger(const Passenger &p)
{
    int index = -1; // Initially assuming that the passenger isn't found
    for (int i = 0; i < passengers_count; i++)
    { // searching for the passenger name
        if (passengers[i].getName() == p.getName())
        {
            break;
        }
    }
    if (index == -1)
    {
        cout << "Passenger not found." << endl;
        return; // exit the function
    }
    for (int i = index; i < passengers_count - 1; i++)
    {
        passengers[i] = passengers[i + 1]; // Move each passenger to the left
    }
    int row = index / 6;           // Find the row using index
    int seat = index % 6;          // Find the seat in the row
    seating_plan[row][seat] = '0'; // Mark the seat as empty
    passengers_count--;
    cout << "Passenger " << p.getName() << " has been removed." << endl;
} // updates seating plan

void Flight::add_passengers(Passenger *newPassengers, int numOfPassengers)
{
    while (passengers_count + numOfPassengers > seating_capacity)
    {
        // this should always make room to add new passengers if the capacity is not enough by using the overloaded++
        ++(*this);
        // resize the passenger array when needed
        ResizePassengersArray();
    }
    for (int i = 0; i < numOfPassengers; ++i)
    {
        *this += newPassengers[i]; // Assign passenger and seat
    }
}

Flight::Flight(string num, int capacity, string dest)
{
    flight_num = num;
    seating_capacity = capacity;
    destination = dest;
    passengers_count = 0;
    departure_time = " ";
    time_zone = " ";
    passengers = new Passenger[capacity]; // allocates memory for the dynamic arrays with an appropriate size
    InitialSeatingPlan();                 // initialize the seating plan
} // departure time and time zone are initialized to empty strings

Flight::~Flight()
{
    delete[] passengers;
    for (int i = 0; i < seating_capacity; i++)
    {
        delete[] seating_plan[i];
    }
    delete[] seating_plan;
} // Destructor frees up the dynamically allocated memory