//Malak Moustafa 20237015
//Jumanah Muhammad 20237003
#ifndef HELLOWORLD_PASSENGER_H
#define HELLOWORLD_PASSENGER_H

#include <iostream>
using namespace std;
#include <cstring>
class Passenger{
    friend class Flight;
private:
    string name;
    string ID;
    static int totalpassengers;

public:
    Passenger() // default constructor
    {
        name = "";
        ID = "";
        //++totalpassengers;
    }
    Passenger(string Name, int id)
    {
        name = Name;
        ID = id;
        ++totalpassengers;
    } // Each time a passenger is added increment totalpassengers
    string getName() const { return name; }
    string getID() const { return ID; }
    void DisplayPassengerDetails() const;
    static void DisplayTotalPassengers();
    friend istream &operator>>(istream &is, Passenger &passenger);
    // Custom function for managing removal
    static void decrementPassengerCount()
    {
        if (totalpassengers > 0)
        {
            --totalpassengers;
        }
        cout << "This passenger has been removed." << endl;
        cout << "Passengers now are: " << totalpassengers << endl;
    }
    ~Passenger() {
        totalpassengers--;
        cout << "Destructor of Passenger class" << endl;
    }
};


#endif //HELLOWORLD_PASSENGER_H
