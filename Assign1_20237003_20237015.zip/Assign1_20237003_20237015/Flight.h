//Malak Moustafa 20237015
//Jumanah Muhammad 20237003
#ifndef HELLOWORLD_FLIGHT_H
#define HELLOWORLD_FLIGHT_H
#include "Passenger.h"
#include <iostream>
#include <cstring>

class Flight
{
private:
    string flight_num;
    int seating_capacity; // booked_seats;
    string destination, departure_time, time_zone;
    int passengers_count;
    Passenger *passengers; // dynamic array to store the passengers' names
    char **seating_plan;   // a 2d dynamic array to display seats and provide info about them being reserved or not
    // X for reserved and 0 for empty
    void ResizePassengersArray(); // to resize the passengers array
    void InitialSeatingPlan();    // to give initial values for the seating_plan 2d array
public:
    Flight(string num, int capacity, string dest); // constructor
    // Destructor
    friend ostream &operator<<(ostream &os, const Flight &flight);      // to overload the output operator
    Flight &operator++();                                               // to overload the ++ prefix operator
    bool search_passenger(const string name);                          // to search for a passenger
    bool search_seat(int seat_num) const;                               // to determine if a seat is booked or not
    void DisplayFlightDetails() const;                                  // to display all of the flight details
    void add_passengers(Passenger *newPassengers, int numOfPassengers); // to add passengers
    friend ostream &operator<<(ostream &os, const Flight &flight);
    Flight &operator+=(const Passenger p);
    Flight &operator--(int);
    Flight &operator-=(int num_passengers);
    void removePassenger(const Passenger &p);
    ~Flight(); // deconstructor
};

#endif //HELLOWORLD_FLIGHT_H
