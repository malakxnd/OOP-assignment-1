//Malak Moustafa 20237015
//Jumanah Muhammad 20237003
#include <iostream>
#include <cstring>
#include "Passenger.h"
#include "Flight.h"
using namespace std;

int main()
{
    string flight_num;
    int seating_capacity;
    string destination;
    int NumOfPassengers;
    string searchName;
    int seatNum;
    // variable declaration
    cout << "Enter flight number: ";
    cin >> flight_num;
    cout << "Enter seating capacity: ";
    cin >> seating_capacity;
    cout << "Enter destination: ";
    cin.ignore(); // Clear the newline from previous input so that getline will work properly
    getline(cin, destination);
    // create a Flight object
    Flight flight(flight_num, seating_capacity, destination);
    // asking the user to input the number of passengers
    cout << "Enter the number of passengers: ";
    cin >> NumOfPassengers;
    Passenger *passengers = new Passenger[NumOfPassengers]; // create a dynamic array of Passenger objects
    cin.ignore();                                           // ignore cleans the buffer so that getline works well
    for (int i = 0; i < NumOfPassengers; i++)
    {
        string name, id;
        cout << "Enter name for passenger " << i + 1 << ": ";
        getline(cin, name);
        cout << "Enter ID for passenger " << i + 1 << ": ";
        getline(cin, id);
        passengers[i] = Passenger(name, id);
    }
    flight.add_passengers(passengers, NumOfPassengers); // adding passengers to the array
    cout << "Enter a passenger name to search: ";       // searching for passenger name
    flight.search_passenger("XXX");
    cout << "Passenger is: " << (flight.search_passenger(searchName) ? "Present" : "Absent") << endl;
    cout << "Enter a seat number to check if it's booked: ";
    cin >> seatNum; // checking if the seat is booked
    cout << "This seat is " << (flight.search_seat(seatNum) ? "booked" : "available") << endl;
    cout << flight; // displaying flight details using << overloader
    ++flight;
    cout << "using operator ++: " << endl;
    cout << flight << endl;
    cout << "using operator --: " << endl;
    flight--;
    cout << flight << endl;
    Passenger p;
    cout << "using operator+=: " << endl;
    flight += p;
    cout << flight << endl;

    return 0;
}